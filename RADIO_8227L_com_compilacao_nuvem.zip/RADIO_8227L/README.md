# RÁDIO 8227L — projeto Android

Atalho Android para abrir o aplicativo de rádio FM original da central multimídia 8227L.

## Identificação

- Nome exibido: **RÁDIO**
- Pacote: `br.radio.atalho`
- Activity própria: `br.radio.atalho.MainActivity`
- Destino explícito: `com.ts.MainUI/com.ts.main.radio.RadioMainActivity`
- `minSdk`: 23
- `targetSdk`: 28 (Android 9)
- Linguagem: Java

## Como funciona

A LiteDash encontra este APK como um aplicativo convencional porque ele declara uma Activity exportada com os filtros `MAIN` e `LAUNCHER`. Ao iniciar, essa Activity dispara um Intent explícito para a tela do rádio original e encerra o atalho.

O projeto não instala, modifica ou substitui `com.ts.MainUI` e não exige root.

## Como compilar no Android Studio

1. Instale o Android Studio e um JDK 17.
2. Abra a pasta `RADIO_8227L` pelo Android Studio.
3. Aguarde a sincronização do Gradle.
4. Se necessário, instale pelo SDK Manager o Android SDK Platform 35 e as Build Tools solicitadas pelo Gradle.
5. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK de depuração será gerado em:
   `app/build/outputs/apk/debug/app-debug.apk`
7. Renomeie esse arquivo para `RADIO.apk`, se desejar, e instale na central.

Para gerar uma versão assinada: **Build > Generate Signed Bundle / APK > APK**, crie ou selecione uma chave e conclua o assistente.

## Seleção na LiteDash

Depois de instalar, abra a lista de aplicativos da LiteDash e procure **RÁDIO**. Selecione-o em **Buscar app** no widget de rádio FM.

## Observações e diagnóstico

- A configuração `<queries>` declara a visibilidade do pacote original para versões Android 11 ou superiores. No Android 9, a consulta de pacotes não é restringida.
- O projeto usa `targetSdk 28`, adequado ao Android 9.
- O nome do pacote e o nome da Activity de destino precisam corresponder exatamente aos informados.
- Se aparecer a mensagem de que não foi possível encontrar o rádio, confirme se o app original está instalado e se o nome real da Activity é `com.ts.main.radio.RadioMainActivity`.
- Se o sistema informar bloqueio de segurança, a Activity original pode não estar exportada ou pode exigir permissões/condições próprias do firmware. Um app intermediário não consegue contornar essa restrição.
- O comportamento de reconhecimento na LiteDash depende também de como ela enumera aplicativos instalados; o filtro `MAIN` + `LAUNCHER` é o mecanismo Android padrão para aparecer no launcher.


## Compilação pelo celular (GitHub Actions)

O arquivo `.github/workflows/android-build.yml` permite compilar na nuvem. Envie o conteúdo desta pasta para um repositório GitHub chamado `radio-8227l`, na branch `main`. Depois abra **Actions > Build RÁDIO APK > Run workflow**. Quando terminar, abra a execução e baixe o artefato `RADIO-apk` (ZIP); dentro dele estará `app-debug.apk`.
