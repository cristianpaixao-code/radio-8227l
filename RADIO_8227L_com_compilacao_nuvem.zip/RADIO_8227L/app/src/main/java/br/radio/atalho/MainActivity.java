package br.radio.atalho;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Toast;

/**
 * Atalho lançador para o rádio FM original da central 8227L.
 * Não altera nem substitui o aplicativo original.
 */
public class MainActivity extends Activity {

    private static final String RADIO_PACKAGE = "com.ts.MainUI";
    private static final String RADIO_ACTIVITY =
            "com.ts.main.radio.RadioMainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        openOriginalRadio();
    }

    private void openOriginalRadio() {
        Intent intent = new Intent();
        intent.setComponent(new ComponentName(RADIO_PACKAGE, RADIO_ACTIVITY));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        try {
            // A chamada explícita tenta iniciar exatamente a Activity solicitada.
            startActivity(intent);
            finish();
        } catch (ActivityNotFoundException e) {
            showError("Não foi possível encontrar o rádio original da central.");
        } catch (SecurityException e) {
            showError("A central bloqueou a abertura do rádio original.");
        } catch (Exception e) {
            showError("Erro ao abrir o rádio FM: " + e.getMessage());
        }
    }

    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        finish();
    }
}
